//
//  DashboardViewController.swift
//  CodingTask
//
//  Created by Mallikarjun H on 15/05/24.
//

import UIKit
import SVProgressHUD
import DGCharts

class DashboardViewController: UIViewController {

    var dashboardModel:CodingTask.Welcome?
    var greetingMessage = ""
    
    @IBOutlet weak var greetingMsgLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var bgView1: UIView!
    @IBOutlet weak var dateRangeSubView: UIView!
    @IBOutlet weak var dateRangeLabel: UILabel!
    
    @IBOutlet weak var chartViewOutlet: LineChartView!
    var dataEntries: [ChartDataEntry] = []
    var overAllUrlChartData:[String:Int] = [:]
    var overAllUrlChartDateArray:[String] = []
    var overAllUrlChartValueArray:[Double] = []
    
    @IBOutlet weak var analyticsCollectionView: UICollectionView!
    let analyticsImgArr = ["totalclicksICN","toplocationICN","topsourceICN"]
    var analyticsTitleArr = ["","",""]
    let analyticsSubtitleArr = ["Today’s clicks","Top Location","Top source"]
    
    @IBOutlet weak var viewAnalyticsBtn: UIButton!
    @IBOutlet weak var viewAllLinksBtn: UIButton!
    @IBOutlet weak var linksTableview: UITableView!
    @IBOutlet weak var linksSegmentedControl: UISegmentedControl!
    
    var isTopLinksSelected = true
    var topLinksArray:[Link] = []
    var recentLinksArray:[Link] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupAndLoadUIAndOtherData()
        
        if Reachability.isConnectedToNetwork(){
            self.getDashboardDetails()
        }else {
            self.showAlert("No Internet", message: "Please check your internet connection and try again")
        }
    }

    func setupAndLoadUIAndOtherData() {
        
        //code to get greeting based on current time
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 6..<12 : greetingMessage = "Good Morning"
        case 12 : greetingMessage = "Good Noon"
        case 13..<17 : greetingMessage = "Good Afternoon"
        case 17..<22 : greetingMessage = "Good Evening"
        default: greetingMessage = "Good Night"
        }
        
        self.greetingMsgLbl.text = greetingMessage
        
        chartViewOutlet.clipsToBounds = true
        chartViewOutlet.layer.cornerRadius = 15
        bgView1.clipsToBounds = true
        bgView1.layer.cornerRadius = 15 
        dateRangeSubView.layer.cornerRadius = 8
        dateRangeSubView.clipsToBounds = true
        dateRangeSubView.layer.borderWidth = 0.8
        dateRangeSubView.layer.borderColor = UIColor.lightGray.cgColor
        viewAnalyticsBtn.layer.cornerRadius = 8
        viewAnalyticsBtn.layer.borderWidth = 1
        viewAnalyticsBtn.layer.borderColor =  #colorLiteral(red: 0.8470588235, green: 0.8470588235, blue: 0.8470588235, alpha: 1)
        viewAllLinksBtn.layer.cornerRadius = 8
        viewAllLinksBtn.layer.borderWidth = 1
        viewAllLinksBtn.layer.borderColor =  #colorLiteral(red: 0.8470588235, green: 0.8470588235, blue: 0.8470588235, alpha: 1)
    }

    func getDashboardDetails() {
        
        SVProgressHUD.show(withStatus: "Loading...")
        
        APIManager.shared.getAPICallMethod(apiUrl: API.DashboardNew) { statusCode, isSuccess, msgValue, result  in
        
            if statusCode == 200 && isSuccess {
                
                self.dashboardModel = result
                
                self.recentLinksArray = result?.data.recentLinks ?? []
                self.topLinksArray = result?.data.topLinks ?? []
                self.overAllUrlChartData = result?.data.overallURLChart ?? [:]
                
                //Code to get all keys and convering into specific date formart from overall_url_chart
                let allKeysArray = Array(self.overAllUrlChartData.keys) //received dates in radom order
                let allSortedDateKeys = allKeysArray.sorted(by: { $0.compare($1) == .orderedAscending }) //dates in ascending order
                
                for dateString in allSortedDateKeys {
                    self.overAllUrlChartDateArray.append(self.dateFormatterAtRowCell(created_at: dateString))
                    let valueFromDict =  self.overAllUrlChartData[dateString]
                    self.overAllUrlChartValueArray.append(Double(valueFromDict ?? 0))
                }
                
                self.analyticsTitleArr[0] = "\(result?.totalClicks ?? 0)"
                self.analyticsTitleArr[1] = result?.topLocation ?? ""
                self.analyticsTitleArr[2] = result?.topSource ?? ""
                
                DispatchQueue.main.async {
                    self.setChart(dataPoints: self.overAllUrlChartDateArray, values: self.overAllUrlChartValueArray)
                    self.analyticsCollectionView.reloadData()
                    self.linksTableview.reloadData()
                    SVProgressHUD.dismiss()
                }
                
            }else {
                DispatchQueue.main.async {
                    SVProgressHUD.dismiss()
                    self.showAlert("Error", message: msgValue)
                }
            }
        }
    }
    
    //var dataEntries: [ChartDataEntry] = []
    func setChart(dataPoints: [String], values: [Double]) {
        
        if dataPoints.count > 0 {
            self.dateRangeLabel.text = "\(dataPoints.first ?? "")" + " - " + "\(dataPoints.last ?? "")"
        }
            
        chartViewOutlet.noDataText = "No data available!"
        
        for i in 0 ..< dataPoints.count {
            //print("chart point : \(values[i])")
            let dataEntry = ChartDataEntry(x: Double(i), y: values[i])
            dataEntries.append(dataEntry)
        }
        
        let lineChartDataSet = LineChartDataSet(entries: dataEntries, label: "")
        
        lineChartDataSet.setCircleColor(UIColor.clear)
        lineChartDataSet.circleRadius = 0.0
        lineChartDataSet.lineWidth = 2.0
        lineChartDataSet.valueTextColor = UIColor.clear
        
        lineChartDataSet.colors = [NSUIColor.blue]
        lineChartDataSet.mode = .cubicBezier
        lineChartDataSet.cubicIntensity = 0.2
        lineChartDataSet.drawFilledEnabled = true //hide filled color
        
        var dataSets = [LineChartDataSet]()
        dataSets.append(lineChartDataSet)
        
        
        let lineChartData = LineChartData(dataSets: dataSets)
        chartViewOutlet.data = lineChartData
        
        chartViewOutlet.xAxis.enabled = true
        chartViewOutlet.leftAxis.enabled = true
        chartViewOutlet.rightAxis.enabled = false
        chartViewOutlet.animate(xAxisDuration: 1.5)
        chartViewOutlet.drawGridBackgroundEnabled = false
        chartViewOutlet.xAxis.drawGridLinesEnabled = true
        chartViewOutlet.xAxis.drawAxisLineEnabled = true
        chartViewOutlet.xAxis.labelPosition = .bottom
        chartViewOutlet.xAxis.drawLabelsEnabled = true
        chartViewOutlet.leftAxis.drawGridLinesEnabled = true
        chartViewOutlet.legend.enabled = false
        chartViewOutlet.xAxis.valueFormatter = IndexAxisValueFormatter(values: dataPoints)
    }
    
    @IBAction func segmentedControlAction(_ sender: Any) {
        switch linksSegmentedControl.selectedSegmentIndex{
        case 0:
            self.isTopLinksSelected = true
            linksTableview.reloadData()
        default:
            self.isTopLinksSelected = false
            linksTableview.reloadData()
        }
    }
}

extension DashboardViewController:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return analyticsImgArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = analyticsCollectionView.dequeueReusableCell(withReuseIdentifier: "AnalyticsCell", for: indexPath) as! AnalyticsCell
        
        cell.imageType.image = UIImage(named: self.analyticsImgArr[indexPath.row])
        cell.titleLbl.text = self.analyticsTitleArr[indexPath.row]
        cell.subTitleLbl.text = self.analyticsSubtitleArr[indexPath.row]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var cellSize: CGSize
        cellSize = CGSize(width: 120, height: 120)
        return cellSize
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        
        return UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
    }
}

extension DashboardViewController: UITableViewDataSource, UITableViewDelegate  {
 
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.isTopLinksSelected {
            return topLinksArray.count
        }
        else {
            return recentLinksArray.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = self.linksTableview.dequeueReusableCell(withIdentifier: "TopAndRecentLinkCell") as? TopAndRecentLinkCell else {
            return UITableViewCell()
        }
        if self.isTopLinksSelected {
            let currentData = self.topLinksArray[indexPath.row]
            cell.updateCellDetails(data: currentData)
        }else {
            let currentData = self.recentLinksArray[indexPath.row]
            cell.updateCellDetails(data: currentData)
        }
        return cell
 
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 116.0
    }
}

