//
//  AnalyticsCell.swift
//  CodingTask
//
//  Created by Mallikarjun H on 15/05/24.
//

import UIKit

class AnalyticsCell: UICollectionViewCell {
    
    @IBOutlet weak var imageType: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var subTitleLbl: UILabel!
    
    override func awakeFromNib() {
        
        self.layer.cornerRadius = 8
        self.clipsToBounds = true
    }
}
