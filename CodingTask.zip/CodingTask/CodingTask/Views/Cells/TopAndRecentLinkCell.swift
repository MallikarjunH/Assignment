//
//  TopAndRecentLinkCell.swift
//  CodingTask
//
//  Created by Mallikarjun H on 15/05/24.
//

import UIKit

class TopAndRecentLinkCell: UITableViewCell {
    
    @IBOutlet weak var thumbnailImg: UIImageView!
    @IBOutlet weak var linkNameLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var totalClicksLabel: UILabel!
    @IBOutlet weak var urlLinkLabel: UILabel!
    @IBOutlet weak var bottomSubView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //code to add -- border to view
        let urVB = CAShapeLayer()  //urVB - Your View Border
        urVB.strokeColor = #colorLiteral(red: 0.6588235294, green: 0.7882352941, blue: 1, alpha: 1)
        urVB.lineDashPattern = [1.8, 1.8]
        urVB.frame = bottomSubView.bounds
        urVB.fillColor = nil
        urVB.path = UIBezierPath(rect: bottomSubView.bounds).cgPath
        bottomSubView.layer.addSublayer(urVB)
        
        //code to crop only bottom view - left and right
        bottomSubView.clipsToBounds = true
        bottomSubView.layer.cornerRadius = 10
        bottomSubView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMinXMaxYCorner]
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func updateCellDetails(data:Link) {
        thumbnailImg.loadImageUsingCache(withUrl: data.originalImage)
        linkNameLabel.text = data.title
        dateLabel.text = dateFormatter(created_at: data.createdAt)
        totalClicksLabel.text = "\(data.totalClicks)"
        urlLinkLabel.text = data.webLink
    }
    
    func dateFormatter(created_at: String) -> String {
        let dateString = created_at
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ" //"2022-01-12T13:57:49.000Z"
        let result = dateFormatter.date(from: dateString)
        dateFormatter.dateFormat = "d MMMM yyyy"
        dateFormatter.timeZone = TimeZone(identifier: "UTC")
        let resultString = dateFormatter.string(from: result!)
        return resultString
    }
}
