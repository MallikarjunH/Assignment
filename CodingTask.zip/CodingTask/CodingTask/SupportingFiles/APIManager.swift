//
//  APIManager.swift
//  CodingTask
//
//  Created by Mallikarjun H on 15/05/24.
//

import Foundation
import UIKit
import SVProgressHUD

struct API {
    
    static let baseAPI = "https://api.inopenapp.com/api/v1/"
    static let DashboardNew =  API.baseAPI + "dashboardNew"
    static let authorizationToken = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjU5MjcsImlhdCI6MTY3NDU1MDQ1MH0.dCkW0ox8tbjJA2GgUx2UEwNlbTZ7Rr38PVFJevYcXFI"
}

class APIManager: NSObject, URLSessionDelegate {
    
    static let shared = APIManager()
    
    private override init(){}
    
    //MARK: GET API Call
    public func getAPICallMethod(apiUrl:String, completion: @escaping (_ statusCode:Int, _ isSuccess:Bool, _ msgValue: String, _ result2:CodingTask.Welcome? ) -> Void) {
        
        let headers = [
            "content-type": "application/json",
            "cache-control": "no-cache",
            "authorization": API.authorizationToken
        ]
        
        let request = NSMutableURLRequest(url: NSURL(string: apiUrl )! as URL,
                                          cachePolicy: .useProtocolCachePolicy,
                                          timeoutInterval: 90.0)
        request.httpMethod = "GET"
        request.allHTTPHeaderFields = headers
        
        //let session = URLSession.shared
        let session = URLSession(configuration: URLSessionConfiguration.default, delegate: self, delegateQueue: nil)
        
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if (error != nil) {
                print(error as Any)
                let httpResponse = response as? HTTPURLResponse
                let statusCode = httpResponse?.statusCode ?? 0
                completion(statusCode, false, "An error has occurred !", nil)
            }else {
                let httpResponse = response as? HTTPURLResponse
                let statusCode = httpResponse?.statusCode ?? 0
            
                //let responseDic = try? JSONSerialization.jsonObject(with: data!, options: [])
               // let dicResponse = responseDic as? [String: Any] ?? [String: Any]()
                
                // Decode the JSON response
                do {
                    let decoder = JSONDecoder()
                    //decoder.keyDecodingStrategy = .convertFromSnakeCase // Use this if your JSON keys are snake_case
                    let responseModel = try decoder.decode(Welcome.self, from: data!)
                    //print("Response model: \(responseModel)")
                    
                    let status = responseModel.status
                    if status {
                        completion(statusCode, status, "", responseModel)
                    }else{
                        completion(statusCode, status, "An error has occurred !", nil)
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                }
                
                //let apiResponseModel = try? JSONDecoder().decode(Welcome9.self, from: data!)
                //let status = apiResponseModel?.status ?? false
               // if status {
                   // completion(statusCode, status, "", apiResponseModel)
                //}else {
                   // completion(statusCode, status, "An error has occurred !", nil)
                //}
            }
        })
        dataTask.resume()
    }
}

let imageCache = NSCache<NSString, UIImage>()
extension UIImageView {
    func loadImageUsingCache(withUrl urlString : String) {
        let url = URL(string: urlString)
        if url == nil {return}
        self.image = nil
        
        // check cached image
        if let cachedImage = imageCache.object(forKey: urlString as NSString)  {
            self.image = cachedImage
            return
        }
        SVProgressHUD.show()
        // if not, download image from url
        URLSession.shared.dataTask(with: url!, completionHandler: { (data, response, error) in
            if error != nil {
                print(error!)
                SVProgressHUD.dismiss()
                return
            }
            
            DispatchQueue.main.async {
                if let image = UIImage(data: data!) {
                    imageCache.setObject(image, forKey: urlString as NSString)
                    self.image = image
                    SVProgressHUD.dismiss()
                }else {
                    self.image = UIImage(named: "imgNotFound")
                    SVProgressHUD.dismiss()
                }
            }
            
        }).resume()
    }
}

extension UIViewController {
    //Alert Messages
    func showAlert(_ title: String, message: String) {
        self.showAlert(title, message: message, onDismiss: nil)
    }
    func showAlert(_ title: String, message: String, onDismiss: (() -> Void)?) {
        let alert = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction.init(title: "OK", style: .cancel, handler: { (_) in
            onDismiss?()
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    //DateFormatter
    func dateFormatterAtRowCell(created_at: String) -> String {
        let dateString = created_at
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" //"2023-05-13"
        let result = dateFormatter.date(from: dateString)
        dateFormatter.dateFormat = "d MMM" //"d MMM yyyy"
        let resultString = dateFormatter.string(from: result ?? Date())
        return resultString
    }
}

